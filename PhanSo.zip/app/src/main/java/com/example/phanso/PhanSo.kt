package com.example.phanso

class PhanSo(private var tuso: Float,private var mauso: Float) {
    init {
        if (mauso == 0f) {
            tuso = 1f
            mauso = 1f
        }
    }
    fun printl() {
        println("Phan so la $tuso/$mauso")
    }
    fun add(phanSo: PhanSo) : PhanSo{
        val tuso = this.tuso* phanSo.mauso + this.mauso +phanSo.tuso
        val mauso = this.mauso * phanSo.mauso
        return PhanSo(tuso, mauso)
    }
}