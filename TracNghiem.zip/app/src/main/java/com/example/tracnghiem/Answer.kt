package com.example.tracnghiem

data class Answer(
    val id: String,
    var answer: String
)